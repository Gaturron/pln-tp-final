# -*- coding: utf-8 -*-

import re
import os
import string
import sqlite3

# Funciones auxiliares
from acdclib import mynormalize
from acdclib import mycapitalize

class FrameMateria:	
	#------------------------------------------------------
	# Setup del frame
	# 
	frid = "MATERIA"
	interrogacion = "(que|cual|cuales)"
	regexp  = "(.*) materia"
	profesores = []							# Lista con los profesores (para contrastar con el input)
	dbconn = ""								# Handler de la conexión con la BD	
	#------------------------------------------------------
	interrogacion_ok = 0
	regexp_ok = 0	
	entidad_ok = 0
	#
	entidad_value = ""
	#------------------------------------------------------
	need_info = 0
	msg = ""
	#------------------------------------------------------
	
	def __init__(self, conn, profesores):
		self.dbconn = conn
		self.profesores = profesores
    
	def showMe(self):
		print "------------------------"
		print self.frid
		print self.interrogacion_ok
		print self.regexp_ok
		print self.entidad_ok
		print "------------------------"
	
	def initMe(self):
		self.activo = 0	
		self.interrogacion_ok = 0
		self.regexp_ok = 0		
		self.entidad_ok = ""
		self.error_msg = ""
			
	def testMe(self, utt):
		# Chequeo la interrogación
		if re.search(self.interrogacion, utt):
			self.interrogacion_ok = 1
				
		# Chequeo la expresión regular
		if re.search(self.regexp, utt) or self.regexp_ok == 1:
			self.regexp_ok = 1
			
		# Chequeo la entidad	
		if self.existEntidad(utt):
			#print "ENTIDAD VALUE:*" + self.entidad_value + "*", self.entidad_value.count("*")			
			if self.entidad_value.count("*") > 0:
				self.entidad_ok = 0
				self.need_info = 1
				self.entidad_value = mycapitalize(self.entidad_value)
				self.msg = "Te referis a "				
				
				pfs = self.entidad_value.split("*")				
				for m in pfs:
					self.msg = self.msg + "'" + mycapitalize(m) + "' o "					
				self.msg = self.msg[:-2]
				self.msg = self.msg + "?"
				
				
			else:
				self.entidad_ok = 1
				self.need_info = 0
				self.msg = ""
		else:
			self.entidad_ok = 0
				
	def answer(self):
		ans = ""
		if self.need_info:
			ans = self.msg		
		else:			
			
			#print "interrogacion_ok: ", self.interrogacion_ok 
			#print "regexp_ok.......: ", self.regexp_ok
			#print "entidad_ok......: ", self.entidad_ok
			
			if self.interrogacion_ok and self.regexp_ok and self.entidad_ok:
				# Todo ok => Busco y contesto
				rs = self.search()	
				ans = ""
				
				if len(rs) > 0:			
					ans = "'" + mycapitalize(self.entidad_value) + "' dicta "					
					mr = 0
					for r in rs:				
						if mr == 1:
							ans = ans + " y "
						ans += "'" + mycapitalize(r) + "'"
						mr = 1				
					self.activo = 1			
					self.entidad_ok = 0
				else:
					ans = "No tengo información acerca de ese profesor"
			elif not self.interrogacion_ok:
				ans = "Por favor, escribí tu pregunta"
			elif not self.entidad_ok:
				ans = "No conozco a la persona a la que se refiere"
					
		return ans
		
	def existEntidad(self, utt):
		candidato = []
		
		# Primero reviso las entidades completas
		for pro in self.profesores:				
			x = pro.split("-")
			
			if re.search(x[1], utt) and x[1] != "":
				candidato.append(x[1])
		
		# Sino, proceso las "partes" de las entidades
		if len(candidato) == 0:			
			for pro in self.profesores:		
				x = pro.split("-")
				p = x[1].split()
							
				for z in p:					
					if re.search(z+" ", utt+" ") and len(z) > 3:		
						candidato.append(x[1])
						#print "Candidato: " + x[1] + " por: " + z + " en " + utt
		#-----------------------------------------			
		tc = ""			
		for c in set(candidato):
			tc = tc + c.capitalize() + "*"
		self.entidad_value = tc[:-1].strip()
		
		if self.entidad_value == "":
			return 0
		else:
			return 1
	
	def getScore(self):
		score = 0
		if self.interrogacion_ok:
			score+=2
		if self.regexp_ok:
			score+=1
		if self.entidad_ok != "":			
			score+=1		
		return score
		
	
	def search(self):
		# Crea un objeto cursor y ejecuto el query
		c = self.dbconn.cursor()		
		query = "SELECT DISTINCT m.nombre FROM materias m, dicta d, profesores p WHERE d.idp = p.id AND d.idm = m.id AND p.nombre LIKE '%" + self.entidad_value + "%'";
		#print query		
		
		results = c.execute(query)
		# Itero sobre los resultados
		rs = []
		for row in results:
			nom = mynormalize(row[0].lower())
			rs.append(nom)		
		return rs
#--------------------------------------------------------------------------------------------------
