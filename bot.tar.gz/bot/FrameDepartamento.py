# -*- coding: iso-8859-15 -*-

import re
import os
import string
import sqlite3

class FrameDepartamento:	
	#------------------------------------------------------
	# Setup del frame
	# 
	frid = "DEPARTAMENTO"
	interrogacion = "(quienes|que|cual|cuales)"
	
	regexp_departamento = "(.*) departamento"
	regexp_materias  = "(.*) materias"
	regexp_docentes  = "(.*) docentes|profesores"
	
	profesores = []							# Lista con los profesores (para contrastar con el input)
	materias = []							# Lista con los materias (para contrastar con el input)
	dbconn = ""								# Handler de la conexión con la BD	
	#------------------------------------------------------
	interrogacion_ok = 0
	regexp_departamento_ok = 0
	regexp_materias_ok = 0
	regexp_docentes_ok = 0
	#
	#------------------------------------------------------
	msg = ""
	#------------------------------------------------------
	
	def __init__(self, conn, profesores, materias):
		self.dbconn = conn
		self.profesores = profesores
		self.materias = materias
    
	def showMe(self):
		print "------------------------"
		print self.frid
		print self.interrogacion_ok
		print self.regexp_materias_ok
		print self.regexp_docentes_ok
		print "------------------------"
	
	def initMe(self):
		self.activo = 0	
		self.interrogacion_ok = 0
		self.regexp_departamento_ok = 0
		self.regexp_materias_ok = 0
		self.regexp_docentes_ok = 0
		self.error_msg = ""
			
	def testMe(self, utt):
		# Chequeo la interrogación
		if re.search(self.interrogacion, utt):
			self.interrogacion_ok = 1
				
		# Chequeo la expresión regular
		if re.search(self.regexp_materias, utt):
			self.regexp_materias_ok = 1
			
		if re.search(self.regexp_docentes, utt):
			self.regexp_docentes_ok = 1
			
		if re.search(self.regexp_departamento, utt):
			self.regexp_departamento_ok = 1
				
	def answer(self):
		ans = ""
		if self.interrogacion_ok and (self.regexp_materias_ok or self.regexp_docentes_ok) and self.regexp_departamento_ok:

			if self.regexp_materias_ok:
				ans += "Las materias del departamento son: "
				mr = 0
				for materiaInfo in self.materias:
					aMateriaInfo = materiaInfo.split("-")
					if mr == 1:
						ans += ", "
					ans += aMateriaInfo[1]
					mr = 1
				ans += ". "
			
			if self.regexp_docentes_ok:
				ans += "Los docentes del departamento son: "
				mr = 0
				for docenteInfo in self.profesores:
					aDocenteInfo = docenteInfo.split("-")
					if mr == 1:
						ans += ", "
					ans += aDocenteInfo[1]
					mr = 1
				ans += ". "
			
				self.activo = 1			
			
		elif not self.interrogacion_ok:
			ans = "Por favor, escribí tu pregunta"
		elif not self.regexp_departamento_ok:
			ans = "No entiendo si esta requiriendo informacion general del departamento"
					
		return ans
		
	def existEntidad(self, utt):
		return 1
	
	def getScore(self):
		score = 0
		if self.interrogacion_ok:
			score+=2
		if self.regexp_departamento_ok:
			score+=2
		if self.regexp_materias_ok:
			score+=1		
		if self.regexp_docentes_ok:
			score+=1		
		return score
	
#--------------------------------------------------------------------------------------------------
