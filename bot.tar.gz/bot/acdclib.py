# -*- coding: utf-8 -*-

import re

def mynormalize(x):
    # Tokenizo la entrada. Ojo! Hay que tratar los acentos y eñes
    x = x.lower()
       
    # Esta forma de 're.sub()' funcionó "a veces"... ver:
    # x = re.sub(u'á','a',x,re.UNICODE)       
       
    x = re.sub('á','a',x,re.UNICODE)    
    x = re.sub('é','e',x,re.UNICODE)
    x = re.sub('í','i',x,re.UNICODE)
    x = re.sub('ó','o',x,re.UNICODE)    
    x = re.sub('ú','u',x,re.UNICODE)    
    x = re.sub('ñ','n',x,re.UNICODE)
    x = re.sub('Ñ','n',x,re.UNICODE)
    x = re.sub('ö','o',x,re.UNICODE)
 
    # Elimino carateres no deseados
    x = re.sub("[^a-z09 ]","", x)
    return x

#--------------------------------------------------------------------------------------------------
def mycapitalize(x):	
	ls = x.split()
	x = ""
	for l in ls:
		x = x + l.capitalize() + " "
	
	# Sustituciones para casos especiales
	l1 = ["Iii", "Ii", " Y ", " De ", " En ", " A ", " La ", " Los ", " Con "]
	l2 = ["III", "II", " y ", " de ", " en ", " a ", " la ", " los ", " con "]
	for i in range(0, len(l1)):
		x = re.sub(l1[i],l2[i], x)
		#x = re.sub('Ii','II', x)	
	# Para las Y's y los De's
	#x = re.sub(' Y ',' y ', x)
	#x = re.sub(' De ',' de ', x)
	
	return x.rstrip()
#--------------------------------------------------------------------------------------------------
