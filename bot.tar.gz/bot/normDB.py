# -*- coding: utf-8 -*-

import re
import sqlite3
from acdclib import mynormalize

dbconn = sqlite3.connect('base1.db')
c = dbconn.cursor()

results = []
#results = dbconn.execute('SELECT * FROM Materias')
for row in results:
	idm = row[0]
	nom = mynormalize(row[1])
	#print idm, row[1]
	
	query = "UPDATE materias SET nombre='"+nom+"' WHERE id="+str(idm)+";"
	#print query
	#c.execute(query)
	pass
	

results = dbconn.execute('SELECT * FROM Profesores')
for row in results:
	idm = row[0]
	nom = row[1]
	
	nom = re.sub('Lic.', "", nom)
	nom = re.sub('Dra.', "", nom)
	nom = re.sub('Dr.', "", nom)
	nom = re.sub('A.U.', "", nom)
	nom = re.sub('Mg.', "", nom)
	nom = nom.strip()
	nom = mynormalize(nom)
	#print idm,  nom
	
	query = "UPDATE profesores SET nombre='"+nom+"' WHERE id="+str(idm)+";"
	#print query
	#c.execute(query)
	pass


results = dbconn.execute('SELECT * FROM dicta')
for row in results:
	idm = row[0]
	nom = row[1]
	rng = row[2]
	
	
	print idm,  nom, rng
	
	query = "UPDATE dicta SET rango=ayudante de segunda' WHERE id="+str(idm)+";"
	#print query
	#c.execute(query)
