# -*- coding: iso-8859-15 -*-

import re
import os
import string
import sqlite3

class FrameHorario:	
	#------------------------------------------------------
	# Setup del frame
	# 
	frid = "HORARIO"
	interrogacion = "(cuando|horario|que dia)"
	regexp  = "(.*) es|dicta"
	materias = []							# Lista con las materias (para contrastar con el input)
	dbconn = ""								# Handler de la conexión con la BD	
	#------------------------------------------------------
	interrogacion_ok = 0
	regexp_ok = 0	
	entidad_ok = 0
	#
	entidad_value = ""
	#------------------------------------------------------
	need_info = 0
	msg = ""
	#------------------------------------------------------
	
	def __init__(self, conn, materias):
		self.dbconn = conn
		self.materias = materias
    
	def showMe(self):
		print "------------------------"
		print self.frid
		print self.interrogacion_ok
		print self.regexp_ok
		print self.entidad_ok
		print "------------------------"
	
	def initMe(self):
		self.activo = 0	
		self.interrogacion_ok = 0
		self.regexp_ok = 0		
		self.entidad_ok = ""
		self.error_msg = ""
			
	def testMe(self, utt):
		# Chequeo la interrogación
		if re.search(self.interrogacion, utt):
			self.interrogacion_ok = 1
				
		# Chequeo la expresión regular
		if re.search(self.regexp, utt) or self.regexp_ok == 1:
			self.regexp_ok = 1
			
		# Chequeo la entidad	
		if self.existEntidad(utt):
			#print "ENTIDAD VALUE:*" + self.entidad_value + "*", self.entidad_value.count("*")			
			if self.entidad_value.count("*") > 0:
				self.entidad_ok = 0
				self.need_info = 1
				self.msg = "Te referis a '" + self.entidad_value.replace("*", "' o '") + "'?"
			else:
				self.entidad_ok = 1
				self.need_info = 0
				self.msg = ""
		else:
			self.entidad_ok = 0
				
	def answer(self):
		ans = ""
		if self.need_info:
			ans = self.msg		
		else:			
			
			#print "interrogacion_ok: ", self.interrogacion_ok 
			#print "regexp_ok.......: ", self.regexp_ok
			#print "entidad_ok......: ", self.entidad_ok
			
			if self.interrogacion_ok and self.regexp_ok and self.entidad_ok:
				# Todo ok => Busco y contesto
				rs = self.search()	
				ans = ""
				
				if len(rs) > 0:			
					ans = self.entidad_value + " se dicta "
					mr = 0
					for r in rs:				
						if mr == 1:
							ans = ans + " y "
						ans += "'" + r +  "'"
						mr = 1				
					self.activo = 1			
					self.entidad_ok = 0
				else:
					ans = "No tengo información acerca de esa materia"
			elif not self.interrogacion_ok:
				ans = "Por favor, escribí tu pregunta"
			elif not self.entidad_ok:
				ans = "No conozco la materia a la que se refiere"
					
		return ans
		
	def existEntidad(self, utt):
		candidato = []
		
		# Primero reviso las entidades completas
		for pro in self.materias:				
			x = pro.split("-")
			if re.search(x[1]+" ", utt+ " "):
				candidato.append(x[1])
		
		# Sino, proceso las "partes" de las entidades
		if len(candidato) == 0:			
			for pro in self.materias:
				x = pro.split("-")
				p = x[1].split()
							
				for z in p:
					if re.search(z, utt) and len(z) > 3:
						candidato.append(x[1])
		#-----------------------------------------			
		tc = ""			
		for c in candidato:
			tc = tc + c + "*"
		self.entidad_value = tc[:-1].strip()
		
		if self.entidad_value == "":
			return 0
		else:
			return 1
	
	def getScore(self):
		score = 0
		if self.interrogacion_ok:
			score+=2
		if self.regexp_ok:
			score+=1
		if self.entidad_ok != "":			
			score+=1		
		return score
		
	
	def search(self):
		# Crea un objeto cursor y ejecuto el query
		c = self.dbconn.cursor()		
		query = "SELECT m.* FROM materias m WHERE m.nombre = '" + self.entidad_value + "'";
		#print query		
		
		results = c.execute(query)
		# Itero sobre los resultados
		rs = []
		for row in results:
			nom = row[2]
			rs.append(nom)
			print nom
		return rs
#--------------------------------------------------------------------------------------------------
