# -*- coding: iso-8859-15 -*-

#----------------------------------------------------------------------
#  acdc.py
#  Agente Conversacional del Departamento de Computación
#
#	
#  "Introducción al Procesamiento del Lengauje Natural - 2011"
#
#----------------------------------------------------------------------

import re
import os
import string
import sqlite3

#import random

from time import localtime

# Clases donde se implementan los "frames"
from FrameMateria  import FrameMateria
from FrameProfesor import FrameProfesor
from FrameHorario  import FrameHorario

#--------------------------------------------------------------------------------------------------
def mynormalize(x):
	# Tokenizo la entrada. Ojo! Hay que tratar los acentos y eñes
	x = x.lower()
	
	l1 = ["á", "é", "í", "ó", "ú", "ñ", "Á", "É", "Í", "Ó", "Ú", "Ñ"]
	l2 = ["a", "e", "i", "o", "u", "n", "a", "e", "i", "o", "u", "n"]
	
	for i in range(0, len(l1)):
		#print "Cambio " + l1[i] + " por " + l2[i]
		x = re.sub(l1[i], l2[i], x)
	# Elimino carateres no deseados
	x = re.sub("[^a-z09 ]","", x)
	return x
#--------------------------------------------------------------------------------------------------
def mycapitalize(x):
	ls = x.split()
	
	x = ""
	for l in ls:
		x = x + l.capitalize() + " "
	return x.rstrip()
#--------------------------------------------------------------------------------------------------

def myprune(ex, x):	
	tmp = ex.split("|")	
	for e in tmp:		
		x = re.sub(e, "", x)
			
	return x

def isGreeting(se, x):	
	sl = 0
	if re.search(se, x):
		sl = 1	
		saludo_ok = 1	
	return sl
	
def getGreeting():
	sl = ""
	hour = localtime().tm_hour
	if hour <= 12:
		sl = "buen día" 
	elif hour <= 20:
		sl = "buenas tardes"
	else:
		sl = "buenas noches"
	return sl

#-------------------------------------------------------------------------------------------------

def process(utt, frames):
	# Esta normalización elimina/cambia símbolos no deseados 
	# (acentos, eñes, signos de puntuación, etc.)	
	utt = mynormalize(utt)
	
	# Esta función elimina expresiones del lenguaje que no aportan al proceso 
	
	# VER! Si tiene sentido hacerlo o no
	interjecex = (" ah | ok ")	
	utt = myprune(interjecex, utt)
		
	#------------------------------------------------------------------
	# Veo si es un algún saludo 
	saludosexp = ("hola|que tal|como va|que haces|buen dia|buenas tardes|buenas")	
	if isGreeting(saludosexp, utt):
		global saludo_ok
		if saludo_ok:
			ans = "Si, si... " + getGreeting() + ", en qué te puedo ayudar?"
		else:
			ans = "En qué te puedo ayudar?"
			saludo_ok = 1		
			
	else:
	
		#------------------------------------------------------------------
		interrotativos = "(que|cual|quien|como|donde|por que|cuando|cuanto)"		
		if re.search(interrotativos, utt):
			# Si la nueva 'utt' tiene un interrogativo => 
			#	* Es una pregunta nueva => limpio los frames que tengan estados 'intermedios'
			for f in frames:
				f.initMe()
			pass
		#------------------------------------------------------------------		
		# Evalúo cada frame!
		for f in frames:
			f.testMe(utt)
	
		# Luego de setearlos todos, elijo uno (o varios) que podría ser (por algún criterio)
		maxsc = 0
		fsel  = 0
		for f in frames:
			#f.showMe()
			#print f.frid, f.getScore()
			if f.getScore() > maxsc:
				maxsc = f.getScore()
				fsel = f
	
			if fsel == 0:	
				# Ningún frame es "candidato"
				ans = "En qué te puedo ayudar?"
		else:
			#fsel.showMe()
			#print fsel.getScore()
	
			if maxsc >= 3:
				ans = fsel.answer()
				fsel.activo = 1
			
				for f in frames:
					if f != fsel:
						f.initMe()
			else:
				ans = ""
		
	return ans
		
#--------------------------------------------------------------------------------------------------	

def load(conn, table):
	# Crea un objeto cursor y ejecuto el query
	c = conn.cursor()
	results = c.execute('SELECT * FROM ' + table)
	# Itero sobre los resultados
	p = []
	for row in results:
		idp = row[0]
		nom = row[1]
		p.append(str(idp) + "-" + nom)
	return p






#------------------------------------------------------------------------------------------------	
#  Main
#------------------------------------------------------------------------------------------------	
if __name__ == "__main__":
	
	os.system("clear")

	#----------------------------------------------------------------------------------------
	# Crear la conexión con la base de datos
	dbconn = sqlite3.connect('acdc.db')
	#----------------------------------------------------------------------------------------
	# Cargo los profesores
	profesores = []
	profesores = load(dbconn, "profesores")
	materias = []
	materias = load(dbconn, "materias")
	
	
	#----------------------------------------------------------------------------------------
	# Creo los frames (ver si esto lo metemos luego en la BD)
	frames = []
	f1 = FrameMateria(dbconn, profesores)
	frames.append(f1)
	
	f2 = FrameProfesor(dbconn, materias)
	frames.append(f2)
	
	f3 = FrameHorario(dbconn, materias)
	frames.append(f3)
	
	#----------------------------------------------------------------------------------------
	# Algunas variables auxiliares
	saludo_ok = 0
	hubo_resp = 0
	#
			
	print "---------------------------------------------------------------------------------"
	print "AC\DC"
 	print "Agente Conversacional del Departamento de Computación"
	print "http://dc.uba.ar/"
	print "---------------------------------------------------------------------------------"
	print "ACDC>> Hola, " + getGreeting() + ""

 	utt = ""
	while utt != "chau":
		try:
			utt = raw_input("Vos >> ")
				
			if utt != "":
				# Se procesa la entrada (utt)
				ans = process(utt, frames)
			
				if ans != "":
					print "ACDC>> " + ans			
					hubo_resp = 1
			else:
				if hubo_resp == 1:
					print "ACDC>> Qué mas se te ofrece?"
				else:
					print "ACDC>> Qué se te ofrece?"
				
		except EOFError:
		      	utt = "chau"
				    		
    		
	print "ACDC>> Chau, que tengas " + getGreeting() + "!"
	exit(0)
