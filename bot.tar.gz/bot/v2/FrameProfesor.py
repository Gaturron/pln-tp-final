# -*- coding: iso-8859-15 -*-

import re
import os
import string
import sqlite3

class FrameProfesor:	
	#------------------------------------------------------
	# Setup del frame
	# 
	frid = "PROFESOR"
	interrogacion = "(quien)"
	regexp1 = "(.*) profesor"
	regexp2 = "dicta"
	
	materias = []							# Lista con las materias (para contrastar con el input)
	dbconn = ""								# Handler de la conexión con la BD	
	#------------------------------------------------------
	interrogacion_ok = 0
	regexp_ok = 0	
	entidad_ok = 0
	#
	entidad_value = ""
	#------------------------------------------------------
	need_info = 0
	msg = ""
	#------------------------------------------------------
	
	def __init__(self, conn, materias):
		self.dbconn = conn
		self.materias = materias
    
	def showMe(self):
		print "------------------------"
		print self.frid
		print self.interrogacion_ok
		print self.regexp_ok
		print self.entidad_ok		
		print "------------------------"
	
	def initMe(self):
		self.activo = 0	
		self.interrogacion_ok = 0
		self.regexp_ok = 0		
		self.entidad_ok = ""
		self.error_msg = ""
			
	def testMe(self, utt):
		# Chequeo la interrogación
		if re.search(self.interrogacion, utt):
			self.interrogacion_ok = 1
				
		# Chequeo las expresiones regulares
		if re.search(self.regexp1, utt):
			self.regexp_ok = 1			
		if re.search(self.regexp2, utt):
			self.regexp_ok = 2
			
			
		# Chequeo la entidad	
		if self.existEntidad(utt):
			#print "ENTIDAD VALUE:*" + self.entidad_value + "*", self.entidad_value.count("*")			
			if self.entidad_value.count("*") > 0:
				self.entidad_ok = 0
				self.need_info = 1
				self.msg = "Te referis a '" + self.entidad_value.replace("*", "' o '") + "'?"
			else:
				self.entidad_ok = 1
				self.need_info = 0
				self.msg = ""
		else:
			self.entidad_ok = 0
				
	def answer(self):
		ans = ""
		if self.need_info:
			ans = self.msg		
		else:			
			
			#print "interrogacion_ok: ", self.interrogacion_ok 
			#print "regexp_ok.......: ", self.regexp_ok
			#print "entidad_ok......: ", self.entidad_ok
			
			if self.interrogacion_ok and self.regexp_ok and self.entidad_ok:
				# Todo ok => Busco y contesto
				rs = self.search()	
				ans = ""
				
				if len(rs) > 0:
					# Pregunto qué parte de la regexp usó para hacer 'coherente' la respuesta
					
					if self.regexp_ok == 1:
						if len(rs) == 1:	
							ans = "El profesor de " + self.entidad_value + " es "
						else:
							ans = "Los profesores de " + self.entidad_value + " son "
					
					else:
						if len(rs) == 1:	
							ans = self.entidad_value + " la dicta "
						else:
							ans = self.entidad_value + " la dictan "
						
					mr = 0
					for r in rs:				
						if mr == 1:
							ans = ans + " y "
						ans += "'" + r +  "'"
						mr = 1				
					self.activo = 1			
					self.entidad_ok = 0
				else:
					ans = "No tengo información acerca de esa materia"
			elif not self.interrogacion_ok:
				ans = "Por favor, escribí tu pregunta"
			elif not self.entidad_ok:
				ans = "No conozco la materia a la te referís"
					
		return ans
		
	def existEntidad(self, utt):
		candidato = []
		
		# Primero reviso las entidades completas
		for pro in self.materias:				
			x = pro.split("-")
			if re.search(x[1]+" ", utt+ " "):
				candidato.append(x[1])
		
		# Sino, proceso las "partes" de las entidades
		if len(candidato) == 0:			
			for pro in self.materias:		
				x = pro.split("-")
				p = x[1].split()
							
				for z in p:
					if re.search(z, utt) and len(z) > 3:
						candidato.append(x[1])
		#-----------------------------------------			
		tc = ""			
		for c in candidato:
			tc = tc + c.capitalize() + "*"
		self.entidad_value = tc[:-1].strip()
		
		if self.entidad_value == "":
			return 0
		else:
			return 1
	
	def getScore(self):
		score = 0
		if self.interrogacion_ok:
			score+=2
		if self.regexp_ok:
			score+=1
		if self.entidad_ok != "":			
			score+=1
		return score
		
	
	def search(self):
		# Crea un objeto cursor y ejecuto el query
		c = self.dbconn.cursor()		
		query = "SELECT p.nombre FROM materias m, dicta d, profesores p WHERE d.idp = p.id AND d.idm = m.id AND m.nombre LIKE '%" + self.entidad_value + "%'";
		#print query		
		results = c.execute(query)
		# Itero sobre los resultados
		rs = []
		for row in results:
			nom = row[0].lower()
			rs.append(nom)		
		return set(rs)
#--------------------------------------------------------------------------------------------------
