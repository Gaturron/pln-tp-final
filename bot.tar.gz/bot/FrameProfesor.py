# -*- coding: iso-8859-15 -*-

import re
import os
import string
import sqlite3

# Funciones auxiliares
from acdclib import mynormalize
from acdclib import mycapitalize

class FrameProfesor:	
	#------------------------------------------------------
	# Setup del frame
	# 
	frid = "PROFESOR"
	interrogacion = "(quien)"
	
	regexp_docente = "(.*) docente"
	regexp_profesor = "(.*) profesor"
	regexp_jefetps = "(.*) jefes? de trabajos practicos"
	regexp_ayudanteprimera = "(.*) ayudantes? de primera"
	
	
	regexp_ayudantesegunda = "(.*) ayudante? de segunda"
	
	regexp_dicta = "da|dicta"
	
	materias = []							# Lista con las materias (para contrastar con el input)
	dbconn = ""								# Handler de la conexión con la BD	
	#------------------------------------------------------
	interrogacion_ok = 0
	regexp_ok = 0	
	entidad_ok = 0
	#
	entidad_value = ""
	profesores_filter = ""
	#------------------------------------------------------
	need_info = 0
	msg = ""
	fail_count = 0
	#------------------------------------------------------
	
	def __init__(self, conn, materias):
		self.dbconn = conn
		self.materias = materias
    
	def showMe(self):
		print "------------------------"
		print self.frid
		print self.interrogacion_ok
		print self.regexp_ok
		print self.entidad_ok		
		print "------------------------"
	
	def initMe(self):
		self.activo = 0	
		self.interrogacion_ok = 0
		self.regexp_ok = 0		
		#self.entidad_ok = 0
		self.error_msg = ""
		self.profesores_filter = ""
			
	def testMe(self, utt):
		# Chequeo la interrogación
		if re.search(self.interrogacion, utt):
			self.interrogacion_ok = 1
			
		if re.search(self.regexp_docente, utt):
			self.regexp_ok = 1
			self.profesores_filter = ""
		
		if re.search(self.regexp_profesor, utt):
			self.regexp_ok = 1
			self.profesores_filter = "profesor"
			
		if re.search(self.regexp_jefetps, utt):
			self.regexp_ok = 1
			self.profesores_filter = "jefe de trabajos practicos"
			
		if re.search(self.regexp_ayudanteprimera, utt):
			self.regexp_ok = 1
			self.profesores_filter = "ayudante de primera"
			
		if re.search(self.regexp_ayudantesegunda, utt):
			self.regexp_ok = 1
			self.profesores_filter = "ayudante de segunda"
			
		if re.search(self.regexp_dicta, utt):
			self.regexp_ok = 2
			
		# Chequeo la entidad	
		if self.entidad_ok == 0:
			print "SELF_ENTIDAD: " , self.entidad_ok
			if self.existEntidad(utt):		
				print "ENTIDAD VALUE:*" + self.entidad_value + "*", self.entidad_value.count("*")			
				if self.entidad_value.count("*") > 0:
					self.entidad_ok = 0
					self.need_info = 1
				
					#self.msg = "Te referis a: \n'" + self.entidad_value.replace("*", "' o \n") + "?"				
					self.msg = "Te referis a: "				
					mts = self.entidad_value.split("*")
				
					for m in mts:
						#self.msg = self.msg + "\t\t'" + m + "' o\n"
						self.msg = self.msg + "'" + mycapitalize(m) + "' o "
					
					self.msg = self.msg[:-2]
					self.msg = self.msg + "?"
				
				else:
					self.entidad_ok = 1
					self.need_info = 0
					self.msg = ""
			else:
				self.entidad_ok = 0
				
	def answer(self):
		ans = ""
		if self.need_info:
			ans = self.msg		
		else:			
			print "interrogacion_ok: ", self.interrogacion_ok 
			print "regexp_ok.......: ", self.regexp_ok
			print "entidad_ok......: ", self.entidad_ok
			
			if self.interrogacion_ok and self.regexp_ok and self.entidad_ok:
				
				# Todo ok => Busco y contesto
				rs = self.search()
				ans = ""
				
				if len(rs) > 0:
					for r in rs.keys():
						profesores = rs[r]
						
						if len(ans) > 0:
							ans += ". "
						
						if len(profesores) > 1:
							ans += "Los "
							if r.endswith("r"):
								rango = r + "es"
							else:
								aRango = r.split()
								rango = aRango[0] + "s"
								del aRango[0]
								for parteRango in aRango:
									rango += " " + parteRango
							ans += rango + " son ";
						else:
							ans += "El " + r + " es ";
						
						mr = 0
						for profesor in profesores:
							if mr == 1:
								ans = ans + " y "
							ans += "'" + mycapitalize(profesor) + "'"
							mr = 1
					
					ans += "."
					
					self.activo = 1			
					#self.entidad_ok = 0
					self.fail_count = 0

				else:
					ans = "No tengo informacion acerca de esa materia"
			elif (not self.interrogacion_ok) or (not self.regexp_ok):
				ans = "Por favor, escribi tu pregunta"
				self.fail_count = self.fail_count + 1
				if self.fail_count == 2:
					ans = "Tu pregunta?"
				elif self.fail_count == 3:
					ans = "Dale..."
				elif self.fail_count > 3:
					ans = "Así no te puedo ayudar, lo lamento!"
				
			elif not self.entidad_ok:
				ans = "No conozco la materia a la te referis"
					
		return ans
		
	def existEntidad(self, utt):
		candidato = []
		
		# Primero reviso las entidades completas
		for mat in self.materias:				
			x = mat.split("-")
			
			if re.search(x[1]+" ", utt+ " "):
				candidato.append(x[1])
		
		# Sino, proceso las "partes" de las entidades
		if len(candidato) == 0:			
			for mat in self.materias:		
				x = mat.split("-")
				p = x[1].split()							
				for z in p:
					#print "Z: ", z, "* UTT: ", utt
					if re.search(z+" ", utt+" ") and len(z) > 3:
						candidato.append(x[1])
		#-----------------------------------------			
		tc = ""			
		for c in set(candidato):
			tc = tc + c.capitalize() + "*"
		self.entidad_value = tc[:-1].strip()
		self.entidad_value = self.entidad_value.lower()
		
		if self.entidad_value == "":
			return 0
		else:
			return 1
	
	def getScore(self):
		score = 0
		if self.interrogacion_ok:
			score+=2
		if self.regexp_ok:
			score+=1
		if self.entidad_ok != "":			
			score+=1
		return score
		
	
	def search(self):
		# Crea un objeto cursor y ejecuto el query
		c = self.dbconn.cursor()		
		
		query = "SELECT p.nombre, d.rango FROM materias m, dicta d, profesores p WHERE d.idp = p.id AND d.idm = m.id AND trim(m.nombre) LIKE '%" + self.entidad_value.strip() + "' ";
		if len(self.profesores_filter) > 0:
			query = query + "AND lower(d.rango) = '" + self.profesores_filter + "'"
		query = query + " ORDER BY d.rango"
		
		print query		
		results = c.execute(query)
		
		# Itero sobre los resultados
		rs = dict()
		for row in results:
			nom = mynormalize(row[0].lower())
			rango = row[1].lower()
			if not rango in rs:
				rs[rango] = list()
			rs[rango].append(nom)
		return rs
#--------------------------------------------------------------------------------------------------
